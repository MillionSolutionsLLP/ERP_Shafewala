<?php $__env->startSection('Page-title'); ?>
<i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Page-content'); ?>
<?php echo $__env->make('Panel.V.home_data', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Page-breadcrumb'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('B.L.Plate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>