
<table class="table table-bordered table-hover">






    <tr>
    <th colspan="3"> <strong> Member List</strong> </th>
  
</tr>

	<tr>

	<th colspan="1"> <strong> Name of Bussiness</strong> </th>
	<th colspan="1"> <strong> Connection No</strong> </th>
	<th colspan="1"> <strong> Action</strong> </th>
	
</tr>



<tbody>
<?php if(count($data['table']) > 0): ?>
    
    <?php $__currentLoopData = $data['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    	

    	
    	<td><?php echo e($row['NameOfBussiness']); ?></td>
    	<td><?php echo e($row['ConnectionNo']); ?></td>
    	<?php 
    	//action('/B/MAS/Controller@editTax', ['UniqId' => 1])
    	?>
    	<td ms-live-link="" >
    		
    		<div class="btn-group btn-default">
    		<div class="btn btn-success ms-mod-btn" ms-live-link="<?php echo e(action("\B\MM\Controller@editMember",['UniqId'=>\MS\Core\Helper\Comman::en4url($row['UniqId'])])); ?>"><i class="glyphicon glyphicon-pencil"></i></div>
    	
    		</div>

    	</td>


    </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php elseif(count($data['table']) == 0): ?>
 <tr ><center>
<td colspan="3"> 
 	<div class="col-lg-12 btn btn-info ms-mod-btn" ms-live-link="<?php echo e(action("\B\MAS\Controller@addTNC")); ?>">Add New Terms & Conditions</div></center>
</td>

 </tr>
<?php else: ?>
    Something is wrong !
<?php endif; ?>



</tbody>
	



</table>
