<div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
	

	<?php if(array_key_exists('link',$data)): ?>


	<?php


	$class="\\B\\".$data['link']['mod']."\\Model";

	$class=new $class ();
    $function="get".$data['name'];
	$dlist=$class->$function ();

	?>



<datalist id="<?php echo e($data['name']); ?>List">
	<?php $__currentLoopData = $dlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <option value="<?php echo e($value); ?>"> <?php echo e($key); ?></option>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	
	</datalist>


	<?php endif; ?>

    <?php echo e(Form::label($data['name'], $data['lable'])); ?>

    <?php echo e(Form::text($data['name'], $data['value'],['class'=>'form-control','list'=>$data['name'].'List','tabindex'=>$index,'placeholder'=>'Enter '.$data['lable']] )); ?>

</div>