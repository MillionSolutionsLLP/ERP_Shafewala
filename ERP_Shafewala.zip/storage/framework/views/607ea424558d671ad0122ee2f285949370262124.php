
<div class="panel panel-default">
	
<div class="panel-heading"><h5><strong> <i class="glyphicon glyphicon-home"></i> Paghadi Module Home</strong></h5></div>
<div class="panel-body">


<div class="col-lg-12">
	
<?php

$model=new \B\PM\Model();
		$tableData=$model->get()->toArray();
	
		$data=[

			'table'=>$tableData,
		];
//dd($data);
?>
<?php echo $__env->make("PM.V.Object.ProductList",['data'=>$data], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</div>
	


<div class="col-lg-6">
	
<?php

$model=new \B\PM\Model(1);
		$tableData=$model->get()->toArray();
	
		$data=[

			'table'=>$tableData,
		];
//dd($data);
?>
<?php echo $__env->make("PM.V.Object.ProductType",['data'=>$data], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</div>


<div class="col-lg-6">
	
<?php

$model=new \B\PM\Model(2);
		$tableData=$model->get()->toArray();
	
		$data=[

			'table'=>$tableData,
		];
//dd($data);
?>
<?php echo $__env->make("PM.V.Object.ProductRentSlabList",['data'=>$data], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</div>

</div>

</div>