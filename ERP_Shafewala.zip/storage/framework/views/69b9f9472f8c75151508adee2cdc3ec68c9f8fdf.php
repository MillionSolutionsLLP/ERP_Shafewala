<div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
	<?php
	//dd($data);
	?>
<?php echo e(Form::label($data['name'],$data['lable'])); ?> 


<?php if(array_key_exists('value',$data)): ?>



<?php if(array_key_exists('editLock',$data)): ?>


<?php if( $data['editLock']  ): ?>


 <fieldset disabled> 
 <?php echo e(Form::text($data['name'],$data['value'],['class'=>'form-control','tabindex'=>$index,'readonly','placeholder'=>'Enter '.$data['lable']] )); ?>

 </fieldset>



<?php echo e(Form::hidden($data['name'], $data['value'])); ?>

	

<?php else: ?>

<?php echo e(Form::select($data['name'], $data['data'],$data['value'],['class'=>'form-control'])); ?>


<?php endif; ?>







<?php else: ?>


<?php echo e(Form::select($data['name'], $data['data'],$data['value'],['class'=>'form-control'])); ?>




<?php endif; ?>






<?php else: ?>


<?php echo e(Form::select($data['name'], $data['data'],null,['class'=>'form-control'])); ?>




<?php endif; ?>


</div>

