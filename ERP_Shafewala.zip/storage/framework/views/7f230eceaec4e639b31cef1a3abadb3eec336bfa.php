        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                
                <span role="presentation" class="ms-live-btn ms-history-btn" ms-live-link="<?php echo e((action("\B\Panel\Controller@index_data"))); ?>"><a class="" href="#"><img class="ms-logo" src="<?php echo e(asset('images/billing.png')); ?>" /></a></span>




                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               
            </div>
<div class="collapse navbar-collapse" >
    <?php echo $__env->make('B.L.Object.Left', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('B.L.Object.Right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

 
        </nav>