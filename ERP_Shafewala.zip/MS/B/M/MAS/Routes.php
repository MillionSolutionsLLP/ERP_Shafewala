<?php

\MS\Core\Helper\Comman::loadModuleRoute('B\MAS');