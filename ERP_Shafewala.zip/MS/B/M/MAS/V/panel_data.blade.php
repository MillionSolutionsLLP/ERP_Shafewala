


<div class="">

    <div class="container-fluid">




<div class="col-lg-3">
	
@include("MAS.V.Object.side")
</div>


<div class="col-lg-9">
<div class="ms-mod-tab">
@include("MAS.V.Object.MasterDetails")


</div>

</div>
</div>
</div>


