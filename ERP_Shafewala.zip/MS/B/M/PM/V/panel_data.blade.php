<div class="">

    <div class="container-fluid">




<div class="col-lg-3">
	@include("PM.V.Object.side")

</div>


<div class="col-lg-9">
<div class="ms-mod-tab">

	@include("PM.V.Object.MasterDetails")
</div>

</div>
</div>
</div>


