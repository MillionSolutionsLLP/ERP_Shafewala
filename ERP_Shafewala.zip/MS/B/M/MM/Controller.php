<?php
namespace B\MM;

class Controller extends \App\Http\Controllers\Controller
{
	public function __construct(){
     
    $this->middleware('backend');
        //$this->middleware('groupname')->except(['method_name']);
    }
	public function index(){
		
		$data=[];
		return view('MM.V.panel_data')->with('data',$data);
	}


	public function indexData(){
		$data=[];
	return view('MM.V.Object.MasterDetails')->with('data',$data);
	
	}



	public function addMember(){

		$id=0;
		$build=new \MS\Core\Helper\Builder (__NAMESPACE__);

		$build->title("Add Member")->content($id)->action("addMember");

		$build->btn([
								'action'=>"\\B\\MM\\Controller@indexData",
								'color'=>"btn-info",
								'icon'=>"fa fa-fast-backward",
								'text'=>"Back"
							]);
		$build->btn([
								//'action'=>"\\B\\MAS\\Controller@addCCPost",
								'color'=>"btn-success",
								'icon'=>"fa fa-floppy-o",
								'text'=>"Save"
							]);

		return $build->view();
	}

	public function addMemberPost(R\Member $r){


			$status=200;
			//$tableId=2;
			$rData=$r->all();
			$model=new Model();
			$model->MS_add($rData);	
			$array=[
	 		'msg'=>"OK",
	 		'redirectData'=>action('\B\MM\Controller@indexData'),
			];

	 		$json=collect($array)->toJson();
	 		return response()->json($array, $status);




	}


	public function editMember($UniqId){


			$id=0;
			$model=new Model();
			$build=new \MS\Core\Helper\Builder (__NAMESPACE__);
			//dd($model->where('UniqId',\MS\Core\Helper\Comman::de4url($UniqId))->get()->first()->toArray());
			
			$data=$model->where('UniqId',\MS\Core\Helper\Comman::de4url($UniqId))->get()->first()->toArray();
			
			//dd($data);

			$build->title("Edit Member ")->content($id,$data)->action("editMemberPost");

			$build->btn([
									'action'=>"\\B\\MM\\Controller@indexData",
									'color'=>"btn-info",
									'icon'=>"fa fa-fast-backward",
									'text'=>"Back"
								]);
			$build->btn([
									//'action'=>"\\B\\MAS\\Controller@editCompany",
									'color'=>"btn-success",
									'icon'=>"fa fa-floppy-o",
									'text'=>"Save"
								]);

			return $build->view();

	}


	public function editMemberPost(R\Member $r){

		$status=200;
			$rData=$r->all();

			//dd($rData);


			$model=new Model();
			$model->MS_update($rData,0);	

			



			//return ;
			$array=[
	 		'msg'=>"OK",
	 	//	'redirect'=>action('\B\Users\Controller@login_form_otp'),
	 		'redirectData'=>action('\B\MM\Controller@indexData'),

	 		// 	'db Password'=>$psw,
	 		// 'in Password'=>$input['Password']
	 		];
	 		$json=collect($array)->toJson();
	 		return response()->json($array, $status);
		
	}

	public function approveMember(){

		$data=[];
	return view('MM.V.Pages.ApproveList')->with('data',$data);
	
	}


	public function findMember(){
		$data=[];
		return view('MM.V.Pages.FindMember')->with('data',$data);
	}


}