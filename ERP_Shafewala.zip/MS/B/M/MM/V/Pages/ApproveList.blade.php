<div class="panel panel-default">
	
<div class="panel-heading"><h5><strong> <i class="glyphicon glyphicon-home"></i> Member Module Home</strong></h5></div>
<div class="panel-body">
	


<div class="col-lg-12">


@include("MM.V.Object.ApproveList")

	</div>

</div>
<div class="panel-footer"></div>

</div>

