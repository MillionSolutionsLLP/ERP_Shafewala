<div class="">

    <div class="container-fluid">
<div class="col-lg-3">
	
@include("MM.V.Object.side")
</div>


<div class="col-lg-9">
<div class="ms-mod-tab">
@include("MM.V.Object.MasterDetails")


</div>

</div>
</div>
</div>