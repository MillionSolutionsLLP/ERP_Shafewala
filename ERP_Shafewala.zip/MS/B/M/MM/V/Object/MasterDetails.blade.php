
<div class="panel panel-default">
	
<div class="panel-heading"><h5><strong> <i class="glyphicon glyphicon-home"></i> Member Module Home</strong></h5></div>
<div class="panel-body">
	


<div class="col-lg-12">
	
<?php

$model=new \B\MM\Model();
		$tableData=$model->get()->toArray();
	
		$data=[

			'table'=>$tableData,
		];
//dd($data);
?>
@include("MM.V.Object.MemberList",['data'=>$data])



</div>

</div>
<div class="panel-footer"></div>

</div>




