<?php

namespace B\MM\R;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;

class Member extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
         return [
            'UniqId'=>"required",
            'NameOfBussiness'=>"required",
            'ConnectionNo'=>"required",
            'PlotNo'=>"required",
            'GstNo'=>"required",
            'CinNo'=>"required",
            'PanNo'=>"required",
            'AddressStreet'=>"required",
            'AddressRoad'=>"required",
            'AddressCity'=>"required",
            'Pincode'=>"required",
            'BankName'=>"required",
            'AccountType'=>"required",
            'AccountNo'=>"required",
            'IfscCode'=>"required",
            'AttnName'=>"required",
            'ContactNo'=>"required",
            'MobileNo'=>"required",
            'FaxNo'=>"required",
            'Email'=>"required",
            ];

    }

                protected function formatErrors(Validator $validator)
{
    
    
    return [
    'msg' => $validator->errors()  ,
   
    ];

   
}

}