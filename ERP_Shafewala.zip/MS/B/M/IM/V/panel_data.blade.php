<div class="container-fluid">




<div class="col-lg-3">
	
@include("IM.V.Object.side")
</div>


<div class="col-lg-9">
<div class="ms-mod-tab">
@include("IM.V.Object.MasterDetails",['data'=>$data])


</div>

</div>
</div>
</div>

