<div class="">

    <div class="container-fluid">
<div class="col-lg-3">
	
@include("CCM.V.Object.side")
</div>


<div class="col-lg-9">
<div class="ms-mod-tab">
@include("CCM.V.Object.MasterDetails")


</div>

</div>
</div>
</div>