<?php
namespace B\CCM;

class Controller extends \App\Http\Controllers\Controller
{
	public function __construct(){
     

        //$this->middleware('groupname')->except(['method_name']);
    }
	public function index(){
			
			$data=[];
			return view('CCM.V.panel_data')->with('data',$data);

	}

}