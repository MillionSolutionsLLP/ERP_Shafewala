Hello {{ $name }}
<br>We received login request. your OTP is {{ $code }}.

From<br> 
GUDM