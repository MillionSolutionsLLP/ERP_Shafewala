            <ul class="nav navbar-nav pull-right">
 


   <li class="visible-md visible-lg" role="presentation"><div class="loading ">
   	
   	<img src="{{asset('/images/loading.gif')}}" width="40px" height="40px"> 
   </div> </li>



  <li class="bg-danger" role="presentation"><a href="{{action('\B\Users\Controller@logout')}}"><i class="fa fa-sign-out" aria-hidden="true"></i> Sign out</a></li>
  
</ul>