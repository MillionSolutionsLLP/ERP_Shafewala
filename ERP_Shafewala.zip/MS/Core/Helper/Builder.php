<?php 
namespace MS\Core\Helper;

class Builder{


	public function __construct($namespace){

		$this->namespace=$namespace;
		

	}

	public $title,$content,$action,$btn,$namespace;

	public static $layoutB ="B.L.Pages.Form_data";
	public static $layoutF ="B.L.Pages.Form_data";
	public function title($text){

		$this->title=$text;


		return $this;
	}

	public function content($id,$data=[]){

		//$this->content=$text;

		$class=[
			'',
			$this->namespace,
			'Base'
		];

		$base=implode('\\', $class);

		if(count($data)>0){

			$formdata=$base::genFormData(true,$data,$id);			
			//dd($formdata);
		}else{
			$formdata=$base::genFormData(false,$data,$id);	
		}

		

		$this->content=\MS\Core\Helper\DForm::display($formdata);


		return $this;


	}

	public function action($method){
		
		$class=[
			'',
			$this->namespace,
			'Controller'
		];

		$class=[
			implode('\\', $class),
			$method
		];
		$class=implode('@', $class);
		//dd($class);
		$this->action=$class;

		return $this;

	}

	public function btn($array){

		$this->btn[]=$array;
		return $this;

	}
	

	public function view ($backend=false){

		$data=[

			'form-title'=>$this->title,
			'form-content'=>$this->content,
			'frm-action'=>$this->action,
			"form-btn"=>$this->btn

		];
		if($backend){

			return view(self::$layoutB)->with('data',$data);
		}

		return view(self::$layoutF)->with('data',$data);
	}




}

?>