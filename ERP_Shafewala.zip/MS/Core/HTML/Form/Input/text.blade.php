<div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
	

	@if(array_key_exists('link',$data))


	<?php


	$class="\\B\\".$data['link']['mod']."\\Model";

	$class=new $class ();
    $function="get".$data['name'];
	$dlist=$class->$function ();

	?>



<datalist id="{{$data['name']}}List">
	@foreach($dlist as $value=>$key)
 <option value="{{$value}}"> {{$key}}</option>

	@endforeach

	
	</datalist>


	@endif

    {{ Form::label($data['name'], $data['lable']) }}
    {{ Form::text($data['name'], $data['value'],['class'=>'form-control','list'=>$data['name'].'List','tabindex'=>$index,'placeholder'=>'Enter '.$data['lable']] ) }}
</div>