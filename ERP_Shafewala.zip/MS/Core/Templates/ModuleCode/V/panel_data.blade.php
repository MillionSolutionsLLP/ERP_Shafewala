<div class="container-fluid">




<div class="col-lg-3">
	
@include("{ModuleCode}.V.Object.side")
</div>


<div class="col-lg-9">
<div class="ms-mod-tab">
@include("{ModuleCode}.V.Object.MasterDetails",['data'=>$data])


</div>

</div>
</div>
</div>

