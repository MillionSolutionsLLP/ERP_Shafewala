<?php



\MS\Core\Helper\Comman::loadModuleRoute('{namespace}');
